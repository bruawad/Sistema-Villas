﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para RelatorioFornecedores.xaml
    /// </summary>
    public partial class RelatorioFornecedores : Window
    {
        public RelatorioFornecedores()
        {
            InitializeComponent();
        }

        private void RelatorioFornecedores1_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            cn.Open();

            string selecionar = "SELECT codigo, dataadmissao, nome, endereco, numero, complemento, bairro, cidade, uf, cep, telefone1, celular1, email, site, representante, telefone2, celular2 FROM fornecedores ORDER BY dataadmissao";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgFornecedores.ItemsSource = dt.DefaultView;
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Relatorio frm = new Relatorio();
            frm.Show();
            this.Close();
        }
    }
}
