﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace SistemaVillas
{
    class cone
    {

        private MySqlConnection conexao;

        public void cadcliente(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";

            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();

                string inserir = "INSERT INTO clientes(datacadastro,nome,endereco,numero,complemento,bairro,cidade,uf,cep,telefone,celular,email,site)values('"
                    + mo.DataCadastro + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone1 + "','"
                    + mo.Celular1 + "','"
                    + mo.Email + "','"
                    + mo.Site + "')";

                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }

            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }

        public void cadfuncionarios(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO funcionarios(dataadmissao,nome,endereco,numero,complemento,bairro,cidade,uf,cep,telefone,celular,email,cargo,datademissao)values('"
                    + mo.DataAdmissao + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone1 + "','"
                    + mo.Celular1 + "','"
                    + mo.Email + "','"
                    + mo.Cargo + "','"
                    + mo.DataDemissao + "')";
                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }

        public void cadproduto(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO produto(nomeproduto,tipoproduto,marca,grupo,subgrupo,valorcompra,lucro,valorvenda,localizacao,qtdeestoque)values('"
                    + mo.Nome + "','"
                    + mo.TipoProduto + "','"
                    + mo.Marca + "','"
                    + mo.Grupo + "','"
                    + mo.SubGrupo + "','"
                    + mo.ValorCompra + "','"
                    + mo.Lucro + "','"
                    + mo.ValorVenda + "','"
                    + mo.Localizacao + "','"
                    + mo.QtdeEstoque + "')";
                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }

        public void cadfornecedores(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO fornecedores(dataadmissao,nome,endereco,numero,complemento,bairro,cidade,uf,cep,telefone1,celular1,email,site,representante,telefone2,celular2)values('"
                    + mo.DataAdmissao + "','"
                    + mo.Nome + "','"
                    + mo.Endereco + "','"
                    + mo.Numero + "','"
                    + mo.Complemento + "','"
                    + mo.Bairro + "','"
                    + mo.Cidade + "','"
                    + mo.Uf + "','"
                    + mo.Cep + "','"
                    + mo.Telefone1 + "','"
                    + mo.Celular1 + "','"
                    + mo.Email + "','"
                    + mo.Site + "','"
                    + mo.Representante + "','"
                    + mo.Telefone2 + "','"
                    + mo.Celular2 + "')";

                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }

        public void caditens(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO item(codigovenda,codigoproduto,nomeproduto,valorunitario,quantidade,subtotal)values('"
                    + mo.CodigoVenda + "','"
                    + mo.Codigo + "','"
                    + mo.NomeProduto + "','"
                    + mo.ValorUnitario + "','"
                    + mo.Quantidade + "','"
                    + mo.SubTotal + "')";
                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }

        }

        public void cadvendas(modelos mo)
        {
            string caminho = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
            try
            {
                conexao = new MySqlConnection(caminho);
                conexao.Open();
                string inserir = "INSERT INTO venda(codigo,datavenda,valortotal)values('"
                    + mo.Codigo + "','"
                    + mo.DataVenda + "','"
                    + mo.ValorTotal + "')";
                MySqlCommand comandos = new MySqlCommand(inserir, conexao);
                comandos.ExecuteNonQuery();

                conexao.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro de comandos: " + ex.Message);
            }
        }
    }
}