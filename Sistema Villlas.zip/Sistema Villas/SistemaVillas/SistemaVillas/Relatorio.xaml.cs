﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para Relatorio.xaml
    /// </summary>
    public partial class Relatorio : Window
    {
        public Relatorio()
        {
            InitializeComponent();
        }

        private void BtnClientes_Click(object sender, RoutedEventArgs e)
        {
            
            RelatorioClientes frm = new RelatorioClientes();
            frm.Show();
            this.Close();
            
        }

        private void BtnRelProdutos_Click(object sender, RoutedEventArgs e)
        {
            RelatorioProdutos frm = new RelatorioProdutos();
            frm.Show();
            this.Close();
        }

        private void BtnRelFornecedores_Click(object sender, RoutedEventArgs e)
        {
            RelatorioFornecedores frm = new RelatorioFornecedores();
            frm.Show();
            this.Close();
        }

        private void BtnRelFuncionarios_Click(object sender, RoutedEventArgs e)
        {
            RelatorioFuncionarios frm = new RelatorioFuncionarios();
            frm.Show();
            this.Close();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnVendas_Click(object sender, RoutedEventArgs e)
        {
            RelatorioVendas frm = new RelatorioVendas();
            frm.Show();
            this.Close();
        }
    }
}
