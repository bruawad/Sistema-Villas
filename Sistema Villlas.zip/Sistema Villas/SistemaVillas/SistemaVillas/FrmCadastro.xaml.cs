﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmCadastro.xaml
    /// </summary>
    public partial class FrmCadastro : Window
    {
        public FrmCadastro()
        {
            InitializeComponent();
        }

        private void BtnClientes_Click(object sender, RoutedEventArgs e)
        {
            FrmClientes frm = new FrmClientes();
            frm.Show();
            this.Close();
        }

        private void BtnFuncionarios_Click(object sender, RoutedEventArgs e)
        {
            FrmFuncionarios frm = new FrmFuncionarios();
            frm.Show();
            this.Close();
        }

        private void BtnProdutos_Click(object sender, RoutedEventArgs e)
        {
            FrmProdutos frm = new FrmProdutos();
            frm.Show();
            this.Close();
        }

        private void BtnFornecedores_Click(object sender, RoutedEventArgs e)
        {
            FrmFornecedores frm = new FrmFornecedores();
            frm.Show();
            this.Close();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }
    }
}
