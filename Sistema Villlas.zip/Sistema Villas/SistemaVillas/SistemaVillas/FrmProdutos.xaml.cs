﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmProdutos.xaml
    /// </summary>
    public partial class FrmProdutos : Window
    {
        string nome, tipoProduto, marca, grupo, subGrupo, localizacao, valorVenda;
        double valorCompra, lucro, qtdeEstoque;
        int codigo;

        public FrmProdutos()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }

        private void TxtNomeProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeProduto.Text != "")
                {
                    nome = TxtNomeProduto.Text;
                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Black);
                    TxtTipoProduto.IsEnabled = true;
                    TxtTipoProduto.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeProduto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtNomeProduto.IsEnabled = true;
            TxtNomeProduto.Focus();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.Nome = nome;
            mo.TipoProduto = tipoProduto;
            mo.Marca = marca;
            mo.Grupo = grupo;
            mo.SubGrupo = subGrupo;
            mo.ValorCompra = valorCompra;
            mo.Lucro = lucro;
            mo.ValorVenda = valorVenda;
            mo.Localizacao = localizacao;
            mo.QtdeEstoque = qtdeEstoque;

            db.cadproduto(mo);

            MessageBox.Show("Produto cadastrado com sucesso!");

            TxtNomeProduto.Text = "";
            TxtTipoProduto.Text = "";
            TxtMarca.Text = "";
            TxtGrupo.Text = "";
            TxtSubGrupo.Text = "";
            TxtValorCompra.Text = "";
            TxtLucro.Text = "";
            TxtValorVenda.Text = "";
            TxtLocalizacao.Text = "";
            TxtQuantidade.Text = "";

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtNomeProduto.IsEnabled = false;
            TxtTipoProduto.IsEnabled = false;
            TxtMarca.IsEnabled = false;
            TxtGrupo.IsEnabled = false;
            TxtSubGrupo.IsEnabled = false;
            TxtValorCompra.IsEnabled = false;
            TxtLucro.IsEnabled = false;
            TxtValorVenda.IsEnabled = false;
            TxtLocalizacao.IsEnabled = false;
            TxtQuantidade.IsEnabled = false;
        }

        private void TxtTipoProduto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTipoProduto.Text != "")
                {
                    tipoProduto = TxtTipoProduto.Text;
                    LblTipoProduto.Foreground = new SolidColorBrush(Colors.Black);
                    TxtMarca.IsEnabled = true;
                    TxtMarca.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTipoProduto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }


        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtNomeProduto.Text = "";
            TxtTipoProduto.Text = "";
            TxtMarca.Text = "";
            TxtGrupo.Text = "";
            TxtSubGrupo.Text = "";
            TxtValorCompra.Text = "";
            TxtLucro.Text = "";
            TxtValorVenda.Text = "";
            TxtLocalizacao.Text = "";
            TxtQuantidade.Text = "";

            TxtNomeProduto.IsEnabled = false;
            TxtTipoProduto.IsEnabled = false;
            TxtMarca.IsEnabled = false;
            TxtGrupo.IsEnabled = false;
            TxtSubGrupo.IsEnabled = false;
            TxtValorCompra.IsEnabled = false;
            TxtLucro.IsEnabled = false;
            TxtValorVenda.IsEnabled = false;
            TxtLocalizacao.IsEnabled = false;
            TxtQuantidade.IsEnabled = false;

            nome = null;
            tipoProduto = null;
            marca = null;
            grupo = null;
            subGrupo = null;
            valorCompra = 0;
            lucro = 0;
            valorVenda = null;
            localizacao = null;
            qtdeEstoque = 0;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }

        private void TxtMarca_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtMarca.Text != "")
                {
                    marca = TxtMarca.Text;
                    LblMarca.Foreground = new SolidColorBrush(Colors.Black);
                    TxtGrupo.IsEnabled = true;
                    TxtGrupo.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblMarca.Foreground = new SolidColorBrush(Colors.Red);
                }
            }                
        }

        private void TxtGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtGrupo.Text != "")
                {
                    grupo = TxtGrupo.Text;
                    LblGrupo.Foreground = new SolidColorBrush(Colors.Black);
                    TxtSubGrupo.IsEnabled = true;
                    TxtSubGrupo.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }                
        }

        private void TxtSubGrupo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtSubGrupo.Text != "")
                {
                    subGrupo = TxtSubGrupo.Text;
                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Black);
                    TxtValorCompra.IsEnabled = true;
                    TxtValorCompra.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblSubGrupo.Foreground = new SolidColorBrush(Colors.Red);
                }
            }               
        }

        private void TxtValorCompra_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtValorCompra.Text != "")
                {
                    valorCompra = double.Parse(TxtValorCompra.Text);
                    LblValorCompra.Foreground = new SolidColorBrush(Colors.Black);
                    TxtLucro.IsEnabled = true;
                    TxtLucro.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblValorCompra.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtLucro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtLucro.Text != "")
                {
                    lucro = double.Parse(TxtLucro.Text); //Variável nome recebe o conteúdo da caixa de texto
                    TxtLucro.Text = lucro.ToString("N2") + "%";
                    LblLucro.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtLocalizacao.IsEnabled = true;
                    TxtLocalizacao.Focus(); //Focar na próxima txtbox

                    valorVenda = (valorCompra + (valorCompra * lucro / 100)).ToString();
                    TxtValorVenda.Text = "R$ " + valorVenda;
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblLucro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }       

        private void TxtLocalizacao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtLocalizacao.Text != "")
                {
                    localizacao = TxtLocalizacao.Text;
                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Black);
                    TxtQuantidade.IsEnabled = true;
                    TxtQuantidade.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblLocalizacao.Foreground = new SolidColorBrush(Colors.Red);
                }
            }                
        }

        private void TxtQuantidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtQuantidade.Text != "")
                {
                    qtdeEstoque = double.Parse(TxtQuantidade.Text);
                    LblQuantidade.Foreground = new SolidColorBrush(Colors.Black);
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblQuantidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }                
        }
    }
}
