﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmEstoque.xaml
    /// </summary>
    public partial class FrmEstoque : Window
    {
        double qtdestoque;
        public FrmEstoque()
        {
            InitializeComponent();
        }

        private void FrmEstoque1_Loaded(object sender, RoutedEventArgs e)
        {

            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");

            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            cn.Open();

            string selecionar = "SELECT codigo, nomeproduto,qtdeestoque FROM produto ORDER BY qtdeestoque,nomeproduto";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgEstoque.ItemsSource = dt.DefaultView;
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnRepor_Click(object sender, RoutedEventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=villasgelateria");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("UPDATE produto set qtdeestoque = ? WHERE codigo = ?", conn);
            comm.Parameters.Clear();

            comm.Parameters.Add("@qtdeestoque", MySqlDbType.String).Value = TxtQtdeEstoque.Text;
            comm.Parameters.Add("@codigo", MySqlDbType.String).Value = TxtCodigoItem.Text;

            comm.CommandType = CommandType.Text; /*executa o comando*/
            comm.ExecuteNonQuery();


            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            cn.Open();

            string selecionar = "SELECT codigo, nomeproduto,qtdeestoque FROM produto ORDER BY qtdeestoque,nomeproduto";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgEstoque.ItemsSource = dt.DefaultView;
            TxtCodigoItem.Clear();
            TxtQtdeEstoque.Clear();

        }

        private void DtgEstoque_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid grid = (DataGrid)sender;
            DataRowView row_selected = grid.SelectedItem as DataRowView;
            if (row_selected != null)
            {
                TxtCodigoItem.Text = row_selected["codigo"].ToString();
                TxtQtdeEstoque.Text = row_selected["qtdeestoque"].ToString();

            }
        }

        private void FrmEstoque1_MouseMove(object sender, MouseEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void BtnExcluir_Click(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
            cn.Open();
            string sql = @"DELETE FROM produto WHERE codigo = ?;";
            MySqlCommand cmd = new MySqlCommand(sql, cn);

            cmd.Parameters.Clear();
            cmd.Parameters.Add("codigo", MySqlDbType.Int32).Value = TxtCodigoItem.Text;

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            MessageBox.Show("Exclusão realizada com sucesso!");



            string selecionar = "SELECT codigo, nomeproduto,qtdeestoque FROM produto ORDER BY qtdeestoque,nomeproduto";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgEstoque.ItemsSource = dt.DefaultView;
            cn.Close();

            TxtCodigoItem.Clear();
            TxtQtdeEstoque.Clear();

        }
    }
}
