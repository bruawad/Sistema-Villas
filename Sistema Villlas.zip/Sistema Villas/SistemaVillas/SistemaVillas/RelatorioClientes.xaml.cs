﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para RelatorioClientes.xaml
    /// </summary>
    public partial class RelatorioClientes : Window
    {
        public RelatorioClientes()
        {
            InitializeComponent();
        }

        private void RelatorioClientes1_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            cn.Open();

            string selecionar = "SELECT datacadastro, codigo, nome, endereco, numero, complemento, bairro, cidade, uf, cep, telefone, celular, email, site FROM clientes ORDER BY nome";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgClientes.ItemsSource = dt.DefaultView;
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Relatorio frm = new Relatorio();
            frm.Show();
            this.Close();
        }
    }
}
