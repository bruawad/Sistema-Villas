﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmVenda.xaml
    /// </summary>
    public partial class FrmVenda : Window
    {
        string nomeproduto;
        double quantidade, preco, subtotal, estoque, qtdestoque, total;
        int codigoVenda, codigoproduto;

        private void DtgItens_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid grid = (DataGrid)sender;
            DataRowView row_selected = grid.SelectedItem as DataRowView;
            if (row_selected != null)
            {
                TxtCodigoItem.Text = row_selected["codigoitem"].ToString();                
                qtdestoque = double.Parse(row_selected["quantidade"].ToString());
                TxtCodigoProduto.Text = row_selected["codigoproduto"].ToString();
                subtotal = double.Parse(row_selected["subtotal"].ToString());


                MySqlConnection cn = new MySqlConnection();
                cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
                cn.Open();
                string selecionarprod = "SELECT codigo,qtdeestoque FROM produto WHERE codigo = ?";

                MySqlCommand comm = new MySqlCommand(selecionarprod, cn);
                comm.Parameters.Clear();
                comm.Parameters.Add("@codigo", MySqlDbType.String).Value = TxtCodigoProduto.Text;


            }
        }

        private void BtnFinalizar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.Codigo = codigoVenda;
            mo.DataVenda = DateTime.Now.ToString("dd/MM/yyyy");
            mo.ValorTotal = total;

            db.cadvendas(mo);

            MessageBox.Show("Compra Finalizada com Sucesso!");

            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void BtnVoltar_Click(object sender, RoutedEventArgs e)
        {
            FrmMenu frm = new FrmMenu();
            frm.Show();
            this.Close();
        }

        private void BtnExcluir_Click(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
            cn.Open();
            string sql = @"DELETE FROM item WHERE codigoitem = ?;";
            MySqlCommand cmd = new MySqlCommand(sql, cn);

            cmd.Parameters.Clear();
            cmd.Parameters.Add("codigoitem", MySqlDbType.Int32).Value = TxtCodigoItem.Text;

            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            MessageBox.Show("Exclusão realizada com sucesso!");

           
            //************************************PRODUTO*********************************

            MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=villasgelateria");
            conn.Open();
            MySqlCommand cmm = new MySqlCommand("SELECT * FROM produto " + "WHERE codigo = ?", conn);
            cmm.Parameters.Clear();
            cmm.Parameters.Add("@codigo", MySqlDbType.String).Value = TxtCodigoProduto.Text;
            /*Aqui no commandType tem que definir se vai utilizar uma Stored Procedure

            comm.CommandType = CommandType.Text; /*executao comando*/
            //recebe conteúdo do banco
            MySqlDataReader dr = cmm.ExecuteReader();
            dr.Read();
                        
            TxtQtdEstoque.Text = dr.GetString(10);
            qtdestoque = double.Parse(TxtQtdEstoque.Text) + qtdestoque;


            MySqlCommand comm = new MySqlCommand("UPDATE produto set qtdeestoque = ? WHERE codigo = ?", cn);
            comm.Parameters.Clear();

            comm.Parameters.Add("qtdeestoque", MySqlDbType.String).Value = qtdestoque;
            comm.Parameters.Add("@codigo", MySqlDbType.String).Value = TxtCodigoProduto.Text;

            comm.CommandType = CommandType.Text; /*executa o comando*/
            comm.ExecuteNonQuery();

            //**************************PRODUTO*************************

            string selecionar = "SELECT codigoitem,quantidade,codigoproduto,nomeproduto,valorunitario,subtotal FROM item WHERE codigovenda = ?";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            com.Parameters.Add("@codigovenda", MySqlDbType.String).Value = TxtCodigoVenda.Text;           

            //MySqlDataReader dr = com.ExecuteReader(); //aqui********************
            //dr.Read();

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgItens.ItemsSource = dt.DefaultView;
            CmbVendas.Text = "";

            total = total - subtotal;

            TxtTotal.Text = "R$ " + total.ToString("N2");

            MySqlCommand comma = new MySqlCommand("UPDATE produto set total = ? WHERE codigo = ?", cn);
            comm.Parameters.Clear();

            //limpar todas as caixas de texto
            TxtCodigoProduto.Text = "";
            TxtPreco.Text = "";
            TxtSubtotal.Text = "";
            TxtQtdEstoque.Text = "";
            TxtCodigoItem.Text = "";


        }

        public FrmVenda()
        {
            InitializeComponent();
        }

        private void BtnAdicionar_Click(object sender, RoutedEventArgs e)
        {
            if(TxtQuantidade.Text == "")
            {
                MessageBox.Show("Preencha a quantidade!");
                TxtQuantidade.Focus();
                LblQuantidade.Foreground = new SolidColorBrush(Colors.Red);
            }

            else
            {
                LblQuantidade.Foreground = new SolidColorBrush(Colors.Black);
                codigoVenda = int.Parse(TxtCodigoVenda.Text);
                //*************
                MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=villasgelateria");
                conn.Open();
                MySqlCommand comm = new MySqlCommand("UPDATE produto set qtdeestoque = ? WHERE codigo = ?", conn);
                comm.Parameters.Clear();

                comm.Parameters.Add("@qtdeestoque", MySqlDbType.String).Value = qtdestoque;
                comm.Parameters.Add("@codigo", MySqlDbType.String).Value = TxtCodigoProduto.Text;

                comm.CommandType = CommandType.Text; /*executa o comando*/
                comm.ExecuteNonQuery();
                //**************

                total = subtotal + total;

                TxtQuantidade.Clear();
                TxtPreco.Clear();
                TxtSubtotal.Clear();
                TxtQtdEstoque.Clear();

                TxtTotal.Text = total.ToString();
                codigoproduto = int.Parse(TxtCodigoProduto.Text);

                modelos mo = new modelos();
                cone db = new cone();

                mo.CodigoVenda = codigoVenda;
                mo.Codigo = codigoproduto;
                mo.NomeProduto = CmbVendas.Text;
                mo.ValorUnitario = preco;
                mo.Quantidade = quantidade;
                mo.SubTotal = subtotal;

                db.caditens(mo);

                TxtTotal.Text = "R$ " + total.ToString("N2");

                MessageBox.Show("Produto adicionado com sucesso!");

                TxtQuantidade.Text = "";
                TxtPreco.Text = "";
                TxtSubtotal.Text = "";
                TxtQtdEstoque.Text = "";

                BtnAdicionar.Focus();

                MySqlConnection cn = new MySqlConnection();
                cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
                cn.Open();

                string selecionar = "SELECT codigoitem,quantidade,codigoproduto,nomeproduto,valorunitario,subtotal FROM item WHERE codigovenda = ?";

                MySqlCommand com = new MySqlCommand(selecionar, cn);
                com.Parameters.Clear();
                com.Parameters.Add("@codigovenda", MySqlDbType.String).Value = TxtCodigoVenda.Text;

                //MySqlDataReader dr = com.ExecuteReader(); //aqui********************
                //dr.Read();

                MySqlDataAdapter da = new MySqlDataAdapter(com);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DtgItens.ItemsSource = dt.DefaultView;
                CmbVendas.Text = "";
                TxtQuantidade.IsEnabled = false;
                BtnAdicionar.IsEnabled = false;
            }

            
            

        }

        private void ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) { 

                MySqlConnection conn = new MySqlConnection("SERVER=localhost;USER=root;DATABASE=villasgelateria");
                conn.Open();
                MySqlCommand comm = new MySqlCommand("SELECT * FROM produto " + "WHERE nomeproduto = ?", conn);
                comm.Parameters.Clear();
                comm.Parameters.Add("@nomeproduto", MySqlDbType.String).Value = CmbVendas.Text;
                /*Aqui no commandType tem que definir se vai utilizar uma Stored Procedure

                comm.CommandType = CommandType.Text; /*executao comando*/
                //recebe conteúdo do banco
                MySqlDataReader dr = comm.ExecuteReader();
                dr.Read();

                TxtCodigoProduto.Text = dr.GetString(0);
                TxtPreco.Text = dr.GetString(8);
                preco = double.Parse(TxtPreco.Text);
                TxtQtdEstoque.Text = dr.GetString(10);
                qtdestoque = double.Parse(TxtQtdEstoque.Text);

                TxtPreco.Text = "R$ " + preco.ToString("N2");

                TxtQuantidade.IsEnabled = true;
                BtnAdicionar.IsEnabled = true;

                TxtQuantidade.Focus();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");

            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";
            cn.Open();

            string selecionar = "SELECT * FROM produto";

            MySqlCommand com = new MySqlCommand(selecionar, cn);

            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CmbVendas.DisplayMemberPath = "nomeproduto";
            CmbVendas.ItemsSource = dt.DefaultView;


            MySqlCommand comm = new MySqlCommand("SELECT * FROM item WHERE codigovenda = (SELECT MAX(codigovenda) FROM item)", cn);
            comm.Parameters.Clear();
           
            comm.CommandType = CommandType.Text; /*executao comando*/
            //recebe conteúdo do banco
            MySqlDataReader dr = comm.ExecuteReader();
            dr.Read();

            TxtCodigoVenda.Text = dr.GetString(1).ToString();

            codigoVenda = int.Parse(TxtCodigoVenda.Text) + 1;
            TxtCodigoVenda.Text = codigoVenda.ToString();

        }

        private void TxtQuantidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtQuantidade.Text != "")
                {
                    quantidade = double.Parse(TxtQuantidade.Text);

                    if (quantidade > qtdestoque)
                    {
                        MessageBox.Show("Quantidade indisponível!");
                    }

                    else
                    {
                        quantidade = double.Parse(TxtQuantidade.Text);                        

                        subtotal = quantidade * preco;

                        estoque = double.Parse(TxtQtdEstoque.Text);

                        qtdestoque = estoque - quantidade;

                        TxtQtdEstoque.Text = qtdestoque.ToString();

                        TxtSubtotal.Text = subtotal.ToString();

                        TxtSubtotal.Text = "R$ " + subtotal.ToString("N2");

                        BtnAdicionar.Focus();
                    }



                    
                }
            }
        }
    }
}
