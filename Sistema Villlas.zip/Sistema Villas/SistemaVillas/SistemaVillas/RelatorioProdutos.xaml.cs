﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para RelatorioProdutos.xaml
    /// </summary>
    public partial class RelatorioProdutos : Window
    {
        public RelatorioProdutos()
        {
            InitializeComponent();
        }

        private void RelatorioProdutos1_Loaded(object sender, RoutedEventArgs e)
        {
            MySqlConnection cn = new MySqlConnection();
            cn.ConnectionString = "SERVER=localhost;USER=root;DATABASE=villasgelateria";//"SERVER=db4free.net;PORT=3306;USER=villasgelateria;DATABASE=villasgelateria;PASSWORD=sorveteebom;old guids=true";
            cn.Open();

            string selecionar = "SELECT codigo, nomeproduto, tipoproduto, marca, grupo, subgrupo, valorcompra, lucro, valorvenda, localizacao, qtdeestoque FROM produto ORDER BY nomeproduto";

            MySqlCommand com = new MySqlCommand(selecionar, cn);
            com.Parameters.Clear();
            MySqlDataAdapter da = new MySqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DtgProdutos.ItemsSource = dt.DefaultView;
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Relatorio frm = new Relatorio();
            frm.Show();
            this.Close();
        }
    }
}
