﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmClientes.xaml
    /// </summary>
    public partial class FrmClientes : Window
    {
        string nome, endereco, complemento, bairro, cidade, uf, email, site, dataCadastro, cep, telefone, celular;
        int numero;


        public FrmClientes()
        {
            InitializeComponent();
        }

        private void TxtDataCadastro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDataCadastro.Text != "")
                {
                    dataCadastro = (TxtDataCadastro.Text); //Variável nome recebe o conteúdo da caixa de texto
                    LblDataCadastro.Foreground = new SolidColorBrush(Colors.Black); //Mudar a cor do texto da label para o padrão
                    TxtNomeCompleto.IsEnabled = true;
                    TxtNomeCompleto.Focus(); //Focar na próxima txtbox
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDataCadastro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtNomeCompleto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeCompleto.Text != "")
                {
                    nome = TxtNomeCompleto.Text;
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEndereco.IsEnabled = true;
                    TxtEndereco.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Red);
                }

            }
        }

        private void TxtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {

                if (TxtEndereco.Text != "")
                {
                    endereco = TxtEndereco.Text;
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNumero.IsEnabled = true;
                    TxtNumero.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtComplemento.Text != "")
                {
                    complemento = TxtComplemento.Text;
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Black);
                    TxtBairro.IsEnabled = true;
                    TxtBairro.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumero.Text != "")
                {
                    numero = int.Parse(TxtNumero.Text);
                    LblNumero.Foreground = new SolidColorBrush(Colors.Black);
                    TxtComplemento.IsEnabled = true;
                    TxtComplemento.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNumero.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtBairro.Text != "")
                {
                    bairro = TxtBairro.Text;
                    LblBairro.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCidade.IsEnabled = true;
                    TxtCidade.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblBairro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }


        private void TxtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCidade.Text != "")
                {
                    cidade = TxtCidade.Text;
                    LblCidade.Foreground = new SolidColorBrush(Colors.Black);
                    CmbUf.IsEnabled = true;
                    CmbUf.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
     
        private void CmbUf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbUf.Text != "")
                {
                    uf = CmbUf.Text;
                    LblUf.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCep.IsEnabled = true;
                    TxtCep.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblUf.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtCep_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCep.Text != "")
                {
                    cep = (TxtCep.Text);
                    LblCep.Foreground = new SolidColorBrush(Colors.Black);
                    TxtTelefone.IsEnabled = true;
                    TxtTelefone.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCep.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone.Text != "")
                {
                    telefone = (TxtTelefone.Text);
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCelular.IsEnabled = true;
                    TxtCelular.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtCelular_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular.Text != "")
                {
                    celular = (TxtCelular.Text);
                    LblCelular.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEmail.IsEnabled = true;
                    TxtEmail.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCelular.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
     
        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEmail.Text != "")
                {
                    email = TxtEmail.Text;
                    LblEmail.Foreground = new SolidColorBrush(Colors.Black);
                    TxtSite.IsEnabled = true;
                    TxtSite.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEmail.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
         
        private void TxtSite_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtSite.Text != "")
                {
                    site = TxtSite.Text;
                    LblSite.Foreground = new SolidColorBrush(Colors.Black);
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblSite.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }
        
        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtDataCadastro.IsEnabled = true;
            TxtDataCadastro.Focus();
            TxtDataCadastro.Text = DateTime.Now.ToShortDateString();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtDataCadastro.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCep.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtSite.Text = "";

            TxtDataCadastro.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtSite.IsEnabled = false;

            dataCadastro = null;
            nome = null;
            endereco = null;
            numero = 0;
            complemento = null;
            bairro = null;
            cidade = null;
            uf = null;
            cep = null;
            telefone = null;
            celular = null;
            email = null;
            site = null;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

        }
        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.DataCadastro = dataCadastro;
            mo.Nome = nome;
            mo.Endereco = endereco;
            mo.Numero = numero;
            mo.Complemento = complemento;
            mo.Bairro = bairro;
            mo.Cidade = cidade;
            mo.Uf = uf;
            mo.Cep = cep;
            mo.Telefone1 = telefone;
            mo.Celular1 = celular;
            mo.Email = email;
            mo.Site = site;

            db.cadcliente(mo);

            MessageBox.Show("Cliente cadastrado com sucesso!");

            TxtDataCadastro.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCep.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtSite.Text = "";

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtDataCadastro.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCep.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtSite.IsEnabled = false;
        }

    }
}
