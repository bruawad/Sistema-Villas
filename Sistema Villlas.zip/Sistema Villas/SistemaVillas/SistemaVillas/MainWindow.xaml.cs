﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace SistemaVillas
{
    /// <summary>
    /// Interação lógica para MainWindow.xam
    /// </summary>
    public partial class MainWindow : Window
    {
        int i = 0, verificacao;
        string usuario, senha;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void TxtUsuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                usuario = TxtUsuario.Text;
                PwbSenha.IsEnabled = true;
                PwbSenha.Focus();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TxtUsuario.Focus();
        }

        private void PwbSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                senha = PwbSenha.Password;
                BtnEntrar.IsEnabled = true;
                BtnEntrar.Focus();
            }
        }


        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            Thread.Sleep(1000);
            TxbProgresso.Text = "Em Progresso...";
            PgbLogin.Value = 0;
            i = 0;
            Task.Run(() =>
            {
                while (i < 100)
                {
                    i++;
                    Thread.Sleep(50);
                    this.Dispatcher.Invoke(() => //Usar para atualização
                    {
                        PgbLogin.Value = i;
                        TxbCarregamento.Text = i + "%";
                        TxbProgresso.Text = " " + TxbProgresso.Text;
                        while (i == 100)
                        {
                            if(verificacao < 1)
                            {
                                if (usuario == "1" && senha == "1")
                                {
                                    Hide();
                                    FrmMenu frm = new FrmMenu();
                                    frm.Show();
                                    verificacao++;
                                    break;
                                }
                                else if (usuario == "Bruno" && senha == "5678")
                                {
                                    Hide();
                                    FrmMenu frm = new FrmMenu();
                                    frm.Show();
                                    verificacao++;
                                    //frm.BtnCadastro.IsEnabled = false;
                                    //frm.BtnRelatorio.IsEnabled = false;
                                    break;
                                }
                                else
                                {
                                    MessageBox.Show("Favor preencher o usuário ou senha corretamente");
                                    TxtUsuario.Clear();
                                    PwbSenha.Clear();
                                    TxtUsuario.Focus();
                                    PgbLogin.Value = 0;
                                    PwbSenha.IsEnabled = false;
                                    BtnEntrar.IsEnabled = false;
                                    TxbCarregamento.Text = "0%";
                                    TxbProgresso.Text = "Bem Vindo!";
                                }
                            }
                            break;
                        }
                    });
                }
            });
        }
    }
}
