﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmFornecedores.xaml
    /// </summary>
    public partial class FrmFornecedores : Window
    {
        string nome, endereco, complemento, bairro, cidade, uf, email, site, representante, dataAdmissao, cep, telefone, celular, telefone2, celular2;
        int numero, codigo;

        public FrmFornecedores()
        {
            InitializeComponent();
        }
        private void TxtDatadeAdmissao_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtDatadeAdmissao.Text != "")
                {
                    dataAdmissao = (TxtDatadeAdmissao.Text);
                    LblDatadeAdmissao.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNomeCompleto.IsEnabled = true;
                    TxtNomeCompleto.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblDatadeAdmissao.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtNomeCompleto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNomeCompleto.Text != "")
                {
                    nome = TxtNomeCompleto.Text;
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEndereco.IsEnabled = true;
                    TxtEndereco.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNomeCompleto.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        private void TxtEndereco_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEndereco.Text != "")
                {
                    endereco = TxtEndereco.Text;
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Black);
                    TxtNumero.IsEnabled = true;
                    TxtNumero.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEndereco.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            modelos mo = new modelos();
            cone db = new cone();

            mo.DataAdmissao = dataAdmissao;
            mo.Nome = nome;
            mo.Endereco = endereco;
            mo.Numero = numero;
            mo.Complemento = complemento;
            mo.Bairro = bairro;
            mo.Cidade = cidade;
            mo.Uf = uf;
            mo.Cep = cep;
            mo.Telefone1 = telefone;
            mo.Celular1 = celular;
            mo.Email = email;
            mo.Site = site;
            mo.Representante = site;
            mo.Telefone2 = site;
            mo.Celular2 = site;

            db.cadfornecedores(mo);

            MessageBox.Show("Fornecedor cadastrado com sucesso!");

            TxtDatadeAdmissao.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCEP.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtSite.Text = "";
            TxtRepresentante.Text = "";
            TxtCelular2.Text = "";
            TxtTelefone2.Text = "";

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();

            TxtDatadeAdmissao.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCEP.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtSite.IsEnabled = false;
            TxtRepresentante.IsEnabled = false;
            TxtCelular2.IsEnabled = false;
            TxtTelefone2.IsEnabled = false;
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            TxtDatadeAdmissao.Text = "";
            TxtNomeCompleto.Text = "";
            TxtEndereco.Text = "";
            TxtNumero.Text = "";
            TxtComplemento.Text = "";
            TxtBairro.Text = "";
            TxtCidade.Text = "";
            CmbUf.Text = "";
            TxtCEP.Text = "";
            TxtTelefone.Text = "";
            TxtCelular.Text = "";
            TxtEmail.Text = "";
            TxtSite.Text = "";
            TxtRepresentante.Text = "";
            TxtTelefone2.Text = "";
            TxtCelular2.Text = "";

            TxtDatadeAdmissao.IsEnabled = false;
            TxtNomeCompleto.IsEnabled = false;
            TxtEndereco.IsEnabled = false;
            TxtNumero.IsEnabled = false;
            TxtComplemento.IsEnabled = false;
            TxtBairro.IsEnabled = false;
            TxtCidade.IsEnabled = false;
            CmbUf.IsEnabled = false;
            TxtCEP.IsEnabled = false;
            TxtTelefone.IsEnabled = false;
            TxtCelular.IsEnabled = false;
            TxtEmail.IsEnabled = false;
            TxtSite.IsEnabled = false;
            TxtRepresentante.IsEnabled = false;
            TxtTelefone2.IsEnabled = false;
            TxtCelular2.IsEnabled = false;

            dataAdmissao = null;
            nome = null;
            endereco = null;
            numero = 0;
            complemento = null;
            bairro = null;
            cidade = null;
            uf = null;
            cep = null;
            telefone = null;
            celular = null;
            email = null;
            site = null;
            representante = null;
            telefone2 = null;
            celular2 = null;

            BtnSalvar.IsEnabled = false;
            BtnLimpar.IsEnabled = false;
            BtnNovo.IsEnabled = true;
            BtnNovo.Focus();
        }

        private void TxtNumero_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtNumero.Text != "")
                {
                    numero = int.Parse(TxtNumero.Text);
                    LblNumero.Foreground = new SolidColorBrush(Colors.Black);
                    TxtComplemento.IsEnabled = true;
                    TxtComplemento.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblNumero.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtComplemento_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtComplemento.Text != "")
                {
                    complemento = TxtComplemento.Text;
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Black);
                    TxtBairro.IsEnabled = true;
                    TxtBairro.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblComplemento.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtBairro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtBairro.Text != "")
                {
                    bairro = TxtBairro.Text;
                    LblBairro.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCidade.IsEnabled = true;
                    TxtCidade.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblBairro.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void TxtCidade_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCidade.Text != "")
                {
                    cidade = TxtCidade.Text;
                    LblCidade.Foreground = new SolidColorBrush(Colors.Black);
                    CmbUf.IsEnabled = true;
                    CmbUf.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCidade.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }

        private void CmbUf_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (CmbUf.Text != "")
                {
                    uf = CmbUf.Text;
                    LblUF.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCEP.IsEnabled = true;
                    TxtCEP.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblUF.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
 
        private void TxtCEP_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCEP.Text != "")
                {
                    cep = (TxtCEP.Text);
                    LblCEP.Foreground = new SolidColorBrush(Colors.Black);
                    TxtTelefone.IsEnabled = true;
                    TxtTelefone.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCEP.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtTelefone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone.Text != "")
                {
                    telefone = (TxtTelefone.Text);
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCelular.IsEnabled = true;
                    TxtCelular.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTelefone.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtCelular_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular.Text != "")
                {
                    celular = (TxtCelular.Text);
                    LblCelular.Foreground = new SolidColorBrush(Colors.Black);
                    TxtEmail.IsEnabled = true;
                    TxtEmail.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCelular.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtEmail.Text != "")
                {
                    email = TxtEmail.Text;
                    LblEmail.Foreground = new SolidColorBrush(Colors.Black);
                    TxtSite.IsEnabled = true;
                    TxtSite.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblEmail.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtSite_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtSite.Text != "")
                {
                    site = TxtSite.Text;
                    LblSite.Foreground = new SolidColorBrush(Colors.Black);
                    TxtRepresentante.IsEnabled = true;
                    TxtRepresentante.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblSite.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtRepresentante_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtRepresentante.Text != "")
                {
                    representante = TxtRepresentante.Text;
                    LblRepresentante.Foreground = new SolidColorBrush(Colors.Black);
                    TxtTelefone2.IsEnabled = true;
                    TxtTelefone2.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblRepresentante.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtTelefone2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtTelefone2.Text != "")
                {
                    telefone2 = (TxtTelefone2.Text);
                    LblTelefone2.Foreground = new SolidColorBrush(Colors.Black);
                    TxtCelular2.IsEnabled = true;
                    TxtCelular2.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblTelefone2.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void TxtCelular2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtCelular2.Text != "")
                {
                    celular2 = (TxtCelular2.Text);
                    LblCelular2.Foreground = new SolidColorBrush(Colors.Black);
                    BtnSalvar.IsEnabled = true;
                    BtnSalvar.Focus();
                }
                else
                {
                    MessageBox.Show("Por favor, preencha o campo Corretamente");
                    LblCelular2.Foreground = new SolidColorBrush(Colors.Red);
                }
            }
        }
        
        private void BtnSair_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }
        
        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            TxtDatadeAdmissao.IsEnabled = true;
            TxtDatadeAdmissao.Focus();
            TxtDatadeAdmissao.Text = DateTime.Now.ToShortDateString();

            BtnNovo.IsEnabled = false;
            BtnLimpar.IsEnabled = true;
        }
    }
}
