﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SistemaVillas
{
    /// <summary>
    /// Lógica interna para FrmMenu.xaml
    /// </summary>
    public partial class FrmMenu : Window
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void BtnCadastro_Click(object sender, RoutedEventArgs e)
        {
            FrmCadastro frm = new FrmCadastro();
            frm.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrmEncerrar frm = new FrmEncerrar();
            frm.Show();
            this.Close();
        }

        private void BtnRelatorio_Click(object sender, RoutedEventArgs e)
        {
            Relatorio frm = new Relatorio();
            frm.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void Window_MouseMove(object sender, MouseEventArgs e)
        {
            LblHora.Content = DateTime.Now.ToString("HH:mm");
            LblData.Content = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void BtnEstoque_Click(object sender, RoutedEventArgs e)
        {
            FrmEstoque frm = new FrmEstoque();
            frm.Show();
            this.Close();
        }

        private void BtnVenda_Click(object sender, RoutedEventArgs e)
        {
            FrmVenda frm = new FrmVenda();
            frm.Show();
            this.Close();
        }
    }
}
